/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.officefurniturestock;

/**
 *
 * @author braya
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class request { 
      private Connection connection;
    private int id;
  private String userName;
  private int furnitureId;
  private int quantity;
  private String status;

  public request(int id, String userName, int furnitureId, int quantity, String status) {
    this.id = id;
    this.userName = userName;
    this.furnitureId = furnitureId;
    this.quantity = quantity;
    this.status = status;
  }
  public int getId() {
    return id;
  }
  public String getUserName() {
    return userName;
  }
  public int getFurnitureId() {
    return furnitureId;
  }
  public int getQuantity() {
    return quantity;
  }
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }  
   
}
