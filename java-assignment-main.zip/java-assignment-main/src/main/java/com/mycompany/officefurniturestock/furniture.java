/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.officefurniturestock;

import java.sql.Connection;

/**
 *
 * @author braya
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class furniture {
    private Connection connection;
  private int id;
  private String name;
  private String description;
  private int quantity;
  public furniture(int id, String name, String description, int quantity) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.quantity = quantity;
  }
  public int getId() {
    return id;
  }
  public String getName() {
    return name;
  }
  public String getDescription() {
    return description;
  }
  public int getQuantity() {
    return quantity;
  }
  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }
  
}