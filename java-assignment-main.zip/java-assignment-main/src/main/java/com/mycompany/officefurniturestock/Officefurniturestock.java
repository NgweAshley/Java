/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.officefurniturestock;

/**
 *
 * @author braya
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Officefurniturestock {
  private Connection connection;
  private Scanner scanner;
  public static void main(String[] args) {
  OfficeFurnitureManager manager = new OfficeFurnitureManager();
  while (true) {
    manager.displayMenu();
    int choice = manager.scanner.nextInt();
    manager.scanner.nextLine(); // Consume newline left-over
    switch (choice) {
      case 1:
        manager.addFurniture();
        break;
      case 2:
        manager.displayfurniture();
        break;
      case 3:
        manager.addRequest();
        break;
      case 4: 
        manager.displayRequests();
        break;
      case 5:
        System.out.println("Exiting...");
        return;
      default:
        System.out.println("Invalid choice. Please choose again.");
    }
  }
}

} 