/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.officefurniturestock;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author braya
 */
public class OfficeFurnitureManager {
 public Connection connection;
 public Scanner scanner;
 public OfficeFurnitureManager() {
   try {
 
      Class.forName("com.mysql.cj.jdbc.Driver");
 
      connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/office_furniture", "root", "");
 
      scanner = new Scanner(System.in);
    } catch (ClassNotFoundException | SQLException e) {
      System.out.println("Error connecting to database: " + e.getMessage());
    }
  }  
  public void displayMenu() {
    System.out.println("Office Furniture Stock Management System");
    System.out.println("------------------------------------------------");
    System.out.println("1. Add Furniture");
    System.out.println("2. Display Furniture");
    System.out.println("3. Add Request");
    System.out.println("4. Display Requests");
    System.out.println("5. Exit");
    System.out.print("Enter your choice: ");
  
    }
 public void displayfurniture() {
    try (Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery("SELECT * FROM furniture")) {
      System.out.println("Furniture List:");
      while (resultSet.next()) {
       furniture furniture = new furniture(resultSet.getInt("id"), resultSet.getString("name"), resultSet.getString("description"), resultSet.getInt("quantity"));
      System.out.println("Id:" + furniture.getId() + ", Name:" + furniture.getName() + ", description:" + furniture.getDescription()+ ", Quantity:" + furniture.getQuantity());
    }
  } catch (SQLException e) {
    System.out.println("Error displaying requests: " + e.getMessage());
  }
}

 public void addFurniture() {
    System.out.print("Enter furniture name: ");
    String name = scanner.nextLine();
    System.out.print("Enter furniture description: ");
    String description = scanner.nextLine();
    System.out.print("Enter furniture quantity: ");
    int quantity = scanner.nextInt();
    scanner.nextLine(); // Consume newline left-over
    try (PreparedStatement statement = connection.prepareStatement("INSERT INTO furniture (name, description, quantity) VALUES (?, ?, ?)")) {
      statement.setString(1, name);
      statement.setString(2, description);
      statement.setInt(3, quantity);
      statement.executeUpdate();
      System.out.println("Furniture added successfully!");
    } catch (SQLException e) {
      System.out.println("Error adding furniture: " + e.getMessage());
    } 
  }

// Method to display all requests
public void displayRequests() {
  try (Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery("SELECT * FROM requests")) {
    System.out.println("Request List:");
    while (resultSet.next()) {
      request request = new request(resultSet.getInt("id"), resultSet.getString("user_name"), resultSet.getInt("furniture_id"), resultSet.getInt("quantity"), resultSet.getString("status"));
      System.out.println("ID: " + request.getId() + ", User: " + request.getUserName() + ", Furniture ID: " + request.getFurnitureId() + ", Quantity: " + request.getQuantity() + ", Status: " + request.getStatus());
    }
  } catch (SQLException e) {
    System.out.println("Error displaying requests: " + e.getMessage());
  }
}
// Method to add a new request
public void addRequest() {
  System.out.print("Enter user name: ");
  String userName = scanner.nextLine();
  System.out.print("Enter furniture ID: ");
  int furnitureId = scanner.nextInt();
  scanner.nextLine(); // Consume newline left-over
  System.out.print("Enter quantity: ");
  int quantity = scanner.nextInt();
  scanner.nextLine(); // Consume newline left-over

  try (PreparedStatement statement = connection.prepareStatement("INSERT INTO requests (user_name, furniture_id, quantity, status) VALUES (?, ?, ?, 'Pending')")) {
    statement.setString(1, userName);
    statement.setInt(2, furnitureId);
    statement.setInt(3, quantity);
    statement.executeUpdate();
    System.out.println("Request added successfully!");
  } catch (SQLException e) {
    System.out.println("Error adding request: " + e.getMessage());
  }
}

}
